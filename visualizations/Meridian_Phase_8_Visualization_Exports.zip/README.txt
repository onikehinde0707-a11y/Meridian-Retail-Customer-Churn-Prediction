Meridian Retail Group — Phase 8 Visualization Exports

Extracted directly from the uploaded "Copy of Meridian_Retail_Phase_8_Visualization.ipynb".
No charts were recreated and no data was changed.

Contents:
- 6 Matplotlib PNG chart images (four churn charts, one correlation heatmap, one monthly revenue trend)
- 2 interactive Plotly HTML charts (membership tier and referral source)
- captions.txt with the interpretation text from the notebook

Important methodology note:
The Phase 8 notebook sets the reference date to 1 July 2026 and uses a 180-day inactivity threshold for its churn charts. Keep this definition clearly labelled and do not mix it with any separate 150-day EDA results.
The interactive HTML charts may require an internet connection to load Plotly's JavaScript library.
